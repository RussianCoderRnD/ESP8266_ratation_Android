data class SensorData(
//    список переменных
    val tempSensor1: String,
    val ind_datchik: String,
    val ind_ves: String
)
