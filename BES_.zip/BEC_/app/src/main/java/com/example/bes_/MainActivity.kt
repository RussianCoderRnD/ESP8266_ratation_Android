package com.example.bes_

// Импортируем класс SensorData (предположительно, это пользовательский класс для работы с данными сенсора)
import SensorData

// Импортируем классы из Android SDK для работы с различными компонентами и функционалом приложения
import android.content.Intent // Класс для работы с интентами, используемыми для запуска других активностей или сервисов
import android.content.pm.ActivityInfo // Класс для работы с информацией об активности, в данном случае для задания ориентации экрана
import android.os.Bundle // Класс для передачи данных между активностями
import android.os.Handler // Класс для обработки отложенных задач
import android.os.Looper // Класс для получения основного потока пользовательского интерфейса
import android.util.Log // Класс для логирования сообщений
import android.widget.ImageButton // Класс для работы с кнопками, представляющими изображения
import android.widget.ImageView // Класс для работы с виджетами изображений
import android.widget.TextView // Класс для работы с текстовыми виджетами
import android.widget.Toast // Класс для отображения всплывающих уведомлений (тостов)

// Импортируем функцию для включения режима полноэкранного отображения
import androidx.activity.enableEdgeToEdge

// Импортируем класс для базовой активности приложения
import androidx.appcompat.app.AppCompatActivity

// Импортируем класс Gson для работы с JSON (преобразование JSON в объекты и обратно)
import com.google.gson.Gson

// Импортируем классы из библиотеки OkHttp для выполнения HTTP-запросов
import okhttp3.OkHttpClient // Класс для создания HTTP-клиента
import okhttp3.Request // Класс для создания HTTP-запросов
import okhttp3.MediaType // Класс для работы с типами медиа-контента
import okhttp3.RequestBody // Класс для создания тела HTTP-запроса
import okhttp3.MediaType.Companion.toMediaTypeOrNull // Функция для преобразования строки в объект MediaType
import okhttp3.RequestBody.Companion.toRequestBody // Функция для преобразования строки в объект RequestBody

// Импортируем класс IOException для обработки исключений ввода-вывода
import java.io.IOException


// Константа для задержки в миллисекундах
const val delays = 250

// Основной класс активности
class MainActivity : AppCompatActivity() {
    // Объявляем необходимые переменные
    private lateinit var textViewCount: TextView
    private val client = OkHttpClient() // Создаем экземпляр HTTP клиента
    private val gson = Gson() // Создаем экземпляр Gson для парсинга JSON

    // URL для обращения к ESP8266
    private val url = "http://192.168.14.75/"

    // Объявляем переменные для отображения статуса подключения и данных с датчиков
    private lateinit var statusWiFi: ImageView
    private lateinit var mit_tempSensor1: TextView
    private lateinit var mit_ind_datchik: TextView
    private lateinit var mit_ind_ves: TextView
    private lateinit var imageButtonReturn: ImageButton
    private lateinit var statusBatt: ImageView

    // Handler для выполнения задач с задержкой
    private val handler = Handler(Looper.getMainLooper())
    // Runnable для периодического выполнения fetchDataFromESP8266
    private val fetchDataRunnable = object : Runnable {
        override fun run() {
            fetchDataFromESP8266()
            // Перезапускаем runnable через 1 секунду
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Устанавливаем макет активности
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE // Устанавливаем ориентацию на ландшафтную

        // Проверяем, нужно ли закрыть приложение
        if (intent.getBooleanExtra("EXIT", false)) {
            finish()
        }
        enableEdgeToEdge() // Включаем режим полноэкранного отображения

        // Инициализируем переменные
        mit_tempSensor1 = findViewById<TextView>(R.id.mit_tempSensor1)
        mit_ind_datchik = findViewById<TextView>(R.id.mit_ind_datchik)
        mit_ind_ves = findViewById<TextView>(R.id.mit_ind_ves)

        // Устанавливаем обработчики кнопок и вызываем начальные функции
        A_NameLines()
        fetchDataFromESP8266() // Получаем данные с ESP8266

        // Запускаем периодическое выполнение fetchDataFromESP8266
        handler.postDelayed(fetchDataRunnable, 10000)
    }

    // Функция отображает названия линий и символ "А" на экране
    private fun A_NameLines() {
        val namesLines = listOf("Температура датчика, град : ", "Значения сигнала датчика : ", "Измеренный вес : ")
        val textViewNameLines = findViewById<TextView>(R.id.textViewNameLines)
        val textToShow = namesLines.joinToString(separator = "\n")
        textViewNameLines.text = textToShow
    }

    // Функция для получения данных с ESP8266
    private fun fetchDataFromESP8266() {
        Thread {
            try {
                // Создаем запрос к серверу
                val request = Request.Builder().url(url).build()
                // Выполняем запрос
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        response.body?.string()?.let {
                            // Парсим JSON данные
                            val sensorData = gson.fromJson(it, SensorData::class.java)
                            // Обновляем UI на главном потоке
                            runOnUiThread {
                                statusImegeViwe(
                                    sensorData.tempSensor1,
                                    sensorData.ind_datchik,
                                    sensorData.ind_ves,
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                // Если произошла ошибка, показываем сообщение об ошибке
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Ошибка связи с устройством: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
                Log.e("MainActivity", "Ошибка при отправке или получении данных: ${e.message}", e)
            }
        }.start()
    }

    // Функция для отображения данных с датчиков на экране
    private fun statusImegeViwe(tempSensor1: String, ind_datchik: String, ind_ves: String) {
        mit_tempSensor1.text = tempSensor1
        mit_ind_datchik.text = ind_datchik
        mit_ind_ves.text = ind_ves
    }
}
